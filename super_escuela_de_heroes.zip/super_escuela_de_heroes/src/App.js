import React from 'react';
import './App.css';

function App() {
  return (
    <div>
      <header className="App-header">
        <div className="centro">
          <form action="https://www.dropbox.com/s/tsjhwew35l2e0g4/Super_escuela_de_heroes.pdf.bin">
            <p>
              Reporte de actividades del mes de noviembre 2019
            </p>
            <input type="submit" name="dl" value="1"></input>
          </form>
        </div>
      </header>
    </div>
  );
}

export default App;
